
    
    



select time
from "dwh_sm2"."main"."fact"
where time is null


